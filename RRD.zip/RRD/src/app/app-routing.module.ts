import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContactComponent } from './contact/contact.component';
import { DueComponent } from './due/due.component';
import { HomeComponent } from './home/home.component';
import { PoliciesComponent } from './policies/policies.component';
import { RemediationComponent } from './remediation/remediation.component';

const routes: Routes = [
{
  path:'intro', component:HomeComponent
},
{
  path:'policies', component:PoliciesComponent
},
{
  path:'due', component:DueComponent
},
{
  path:'remediation', component:RemediationComponent
},
{
  path:'contact', component:ContactComponent
},

{ 
  path: '', redirectTo: 'intro', pathMatch: 'full' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
