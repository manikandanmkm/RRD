import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-remediation',
  templateUrl: './remediation.component.html',
  styleUrls: ['./remediation.component.css']
})
export class RemediationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
