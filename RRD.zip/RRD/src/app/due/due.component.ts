import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-due',
  templateUrl: './due.component.html',
  styleUrls: ['./due.component.css']
})
export class DueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
